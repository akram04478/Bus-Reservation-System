
import java.sql.Connection;
import java.sql.DriverManager;

public class DBConnection {
    public static Connection getDBConnection() {
        Connection Connection;
        try {
////            Class.forName("sun.jdbc.odbc.JdbcOdbcDriver");
////            connection = DriverManager.getConnection("jdbc:odbc:Bus");
//connection = DriverManager.getConnection("jdbc:ucanaccess://‪C:\\Users\\Akram\\Documents\\RVB.mdb");
Connection = DriverManager.getConnection("jdbc:ucanaccess://C:\\Users\\Akram\\Documents\\RVB1.accdb");

            return Connection;
        } catch (Exception ex) {
            return null;
        }//try catch closed
    }//getDBConnection() closed
}//class closed
